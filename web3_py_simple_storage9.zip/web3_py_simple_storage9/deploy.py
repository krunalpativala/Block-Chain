import json
import os
from web3 import Web3
from solcx import compile_standard, install_solc
from dotenv import load_dotenv

# Load variables from .env file
load_dotenv()

# Read environment variables
my_address = os.getenv("MY_ADDRESS")
private_key = os.getenv("PRIVATE_KEY")
ganache_url = os.getenv("GANACHE_URL")
chain_id = int(os.getenv("CHAIN_ID"))

# Load Solidity code
with open("./SimpleStorage.sol", "r") as file:
    simple_storage_file = file.read()

# Use local solc folder
os.environ["SOLCX_INSTALL_DIR"] = "./solc_bin"

# Install Solidity compiler
print("Installing Solidity compiler...")
install_solc("0.6.0")

# Compile contract
compiled_sol = compile_standard(
    {
        "language": "Solidity",
        "sources": {"SimpleStorage.sol": {"content": simple_storage_file}},
        "settings": {
            "outputSelection": {
                "*": { 
                    "*": [
                        "abi",
                        "metadata",
                        "evm.bytecode",
                        "evm.bytecode.sourceMap"
                    ]
                }
            }
        },
    },
    solc_version="0.6.0",
)


# Save compilation output
with open("compiled_code.json", "w") as file:
    json.dump(compiled_sol, file, indent=4)

# Extract bytecode & ABI
bytecode = compiled_sol["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["evm"]["bytecode"]["object"]
abi = json.loads(compiled_sol["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["metadata"])["output"]["abi"]

# Connect to Ganache
w3 = Web3(Web3.HTTPProvider(ganache_url))

if w3.is_connected():
    print("Connected to Ganache:", w3.client_version)
else:
    raise Exception("Failed to connect to Ganache")

# Deploy contract
SimpleStorage = w3.eth.contract(abi=abi, bytecode=bytecode)

# Correct nonce
nonce = w3.eth.get_transaction_count(my_address)

transaction = SimpleStorage.constructor().build_transaction({
    "chainId": chain_id,
    "gasPrice": w3.eth.gas_price,
    "from": my_address,
    "nonce": nonce
})

# Sign and send
signed_txn = w3.eth.account.sign_transaction(transaction, private_key=private_key)
print("Deploying contract...")
tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

print(f"Contract deployed at: {tx_receipt.contractAddress}")

# Interacting with contract
simple_storage = w3.eth.contract(address=tx_receipt.contractAddress, abi=abi)

print("Initial Value:", simple_storage.functions.retrieve().call())

# Update value
store_transaction = simple_storage.functions.store(15).build_transaction({
    "chainId": chain_id,
    "gasPrice": w3.eth.gas_price,
    "from": my_address,
    "nonce": nonce + 1
})

signed_store_txn = w3.eth.account.sign_transaction(store_transaction, private_key=private_key)
tx_store_hash = w3.eth.send_raw_transaction(signed_store_txn.raw_transaction)
w3.eth.wait_for_transaction_receipt(tx_store_hash)

print("Updated Value:", simple_storage.functions.retrieve().call())